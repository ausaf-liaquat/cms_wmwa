
<?php $__env->startSection('title'); ?>
    Resources
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h2>My Resources</h2>
            <p>Below are your downloadable resources, links and videos.</p>



            <div class="work-book mt-5">
                <h3 class="pb-0">Downloads</h3>
                <div class="list-group mb-4">
                    <?php $__empty_1 = true; $__currentLoopData = $resources_file; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <a href="<?php echo e(route('resource.download',['id'=>$list->id])); ?>" class="list-group-item list-group-item-action  justify-content-between align-items-start">
                            <i class="bi-download float-start"></i>
                            <div class="ms-5 me-auto">
                                <div class="fw-bold">Category: <?php echo e($list->resource_category); ?></div>
                                <?php echo e($list->resource_file); ?>

                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="list-group-item list-group-item-action  justify-content-between align-items-start">
                            <i class="bi-download float-start"></i>
                            
                            <div class="ms-5 me-auto">
                                <div class="fw-bold">No Data found.</div>
                                
                            </div>
                        </a>
                    <?php endif; ?>
                </div>
                <h3 class="pb-0">Useful Links</h3>
                <div class="list-group mb-4">
                    <?php $__empty_1 = true; $__currentLoopData = $resources_url; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="list-group-item list-group-item-action  justify-content-between align-items-start" href="<?php echo e($list->resource_link); ?>" target="_blank">
                            <i class="bi-link-45deg float-start"></i>
                            <div class="ms-5 me-auto">
                                <div class="fw-bold">Category: <?php echo e($list->resource_category); ?></div>
                                <?php echo e($list->resource_link); ?>

                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a class="list-group-item list-group-item-action  justify-content-between align-items-start">
                            <i class="bi-link-45deg float-start"></i>
                            
                            <div class="ms-5 me-auto">
                                <div class="fw-bold">No Data found.</div>
                                
                            </div>
                        </a>
                    <?php endif; ?>

                </div>
                <h3 class="pb-0">Videos</h3>
                <div class="list-group mb-4">
                    <?php $__empty_1 = true; $__currentLoopData = $resources_video; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <a class="list-group-item list-group-item-action  justify-content-between align-items-start" href="<?php echo e($list->resource_video); ?>" target="_blank">
                            <i class="bi-play-btn float-start"></i>
                            <div class="ms-5 me-auto">
                                <div class="fw-bold">Category: <?php echo e($list->resource_category); ?></div>
                                <?php echo e($list->resource_video); ?>

                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <a data-bs-toggle="modal" data-bs-target="#send"
                            class="list-group-item list-group-item-action  justify-content-between align-items-start">
                            <i class="bi-play-btn float-start"></i>
                            <div class="ms-5 me-auto">
                                <div class="fw-bold"> No Data found.</div>
                                
                            </div>
                        </a>

                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms_app\resources\views/User/resource.blade.php ENDPATH**/ ?>