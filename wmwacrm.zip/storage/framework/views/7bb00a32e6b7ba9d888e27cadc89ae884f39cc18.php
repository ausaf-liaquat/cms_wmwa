<?php $__env->startSection('title'); ?> Register <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form id="register-form" method="POST" action="<?php echo e(route('register')); ?>">
        <?php if($errors->any()): ?>
            <div class="alert with-close alert-danger alert-dismissible fade show">
                <span class="badge rounded-pill bg-danger">Error</span>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <h2>Register with West Mercia Women's Aid</h2>
        <p class="mb-3">Please enter your details below and we will review your request. You will receive a
            notification
            via email once your account has been activated.</p>
        <div class="form-floating mb-3">
            <input type="text" class="form-control " id="name" placeholder="Enter Your Name" name="name" value="">
            <label for="name">Enter Your Name</label>
        </div>
        <div class="form-floating mb-3">
            <input type="email" class="form-control " id="email" placeholder="Enter Your Email Address" name="email"
                value="">
            <label for="email">Enter Your Email Address</label>
        </div>
        <div class="form-floating mb-3">
            <select class="form-select" name="role_id" id="select" aria-label="Floating label select example">
            <option value="practitioner">Practitioner</option>
            <option value="user">User</option>
            </select>
            <label for="select">Select Role</label>
        </div>

        <p class="mb-0">Please enter your password below.</p>
        <div class="form-floating mb-3">
            <input type="password" class="form-control " id="password1" placeholder="Enter your Password" name="password">
            <label for="password1">Enter your Password</label>
        </div>
        <div class="form-floating mb-4">
            <input type="password" class="form-control " id="password2" placeholder="Confirm Your Password"
                name="password_confirmation">
            <label for="password2">Confirm Your Password</label>
        </div>
        
        
        <div class="checkbox mb-4">
            <label>
                <input name="check" type="checkbox" value="signup"> Please sign me up to receive news and updates.
            </label>
        </div>
        <button class="mb-1 w-100 btn btn-primary" type="submit">Request Access</button>
        <p class="mb-3 text-muted float-start">Already have an account? <a href="<?php echo e(route('login')); ?>">Sign in
                here.</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\cms_app\cms_app\resources\views/auth/register.blade.php ENDPATH**/ ?>