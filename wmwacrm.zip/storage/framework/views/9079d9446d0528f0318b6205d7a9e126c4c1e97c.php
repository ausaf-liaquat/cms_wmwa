<?php $__env->startSection('title'); ?> Login <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form id="login-form" method="POST" action="<?php echo e(route('login')); ?>">
        <?php if(session('status')): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <span class="badge rounded-pill bg-success">Success</span>
                <?php echo e(session('status')); ?>

                
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <span class="badge rounded-pill bg-danger">Error</span>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </div>
        <?php endif; ?>
        <?php echo csrf_field(); ?>
        <h2>West Mercia Women's Aid Login</h2>
        <p class="mb-3">Please enter your email address and password</p>
        <div class="form-floating mb-3">
            <input type="email" class="form-control " id="email" placeholder="name@example.com" name="email" value="<?php echo e(old('email')); ?>" autofocus>
            <label for="floatingInput">Email address</label>
        </div>
        <div class="form-floating mb-3">
            <input type="password" class="form-control  " id="password" placeholder="Password" name="password">
            <label for="floatingPassword">Password</label>
        </div>

        <div class="checkbox mb-3">
            <label>
                <input type="checkbox" value="remember-me" name="remember"> Remember me
            </label>
        </div>
        <button class="mb-1 w-100 btn btn-primary" type="submit">Login</button>
        
            <p class="mb-3 text-muted float-start"><a href="<?php echo e(route('password.request')); ?>">Forgotten your password?</a>
            </p>
        
        <p class="mb-3 text-muted float-end">No account? <a href="<?php echo e(route("register")); ?>">Regsiter Here.</a></p>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms_app\resources\views/auth/login.blade.php ENDPATH**/ ?>