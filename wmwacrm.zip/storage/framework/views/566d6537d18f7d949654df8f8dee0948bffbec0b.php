<?php $__env->startSection('title'); ?> Register <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="login-wrap">
        <div class="login-content">
            <div class="login-logo">
                <a href="#">
                    <img src="<?php echo e(asset('assets/images/icon/logo.png')); ?>" alt="CoolAdmin">
                </a>
            </div>
            <div class="login-form">
                <?php if($errors->any()): ?>
                    <div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                        <span class="badge badge-pill badge-danger">Error</span>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($error); ?></p>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                <?php endif; ?>
                <form method="POST" action="<?php echo e(route('register')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Name</label>
                        <input class="au-input au-input--full" type="text" name="name" placeholder="Name">
                    </div>
                    <div class="form-group">
                        <label>Email Address</label>
                        <input class="au-input au-input--full" type="email" name="email" placeholder="Email">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input class="au-input au-input--full" type="password" name="password" placeholder="Password">
                    </div>
                    <div class="form-group">
                        <label>Password Confirmation</label>
                        <input class="au-input au-input--full" type="password" name="password_confirmation"
                            placeholder="Password Confirmation">
                    </div>
                    <div class="form-group">
                        <label>Register as</label>
                        <select name="role_id" id="select" class="au-input au-input--full form-control-lg"
                            style="width: 50%"
                            onchange="if (this.value=='user'){this.form['category'].style.visibility='visible'}else {this.form['category'].style.visibility='hidden'};">
                            <option value="practitioner">Practitioner</option>
                            <option value="user">User</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <input class="au-input au-input--full" type="text" name="category" style="visibility:hidden;"
                            placeholder="Enter Category">
                    </div>

                    <button class="au-btn au-btn--block au-btn--green m-b-20" type="submit">register</button>

                </form>
                <div class="register-link">
                    <p>
                        Already have account?
                        <a href="<?php echo e(route('login')); ?>">Sign In</a>
                    </p>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cms_app\resources\views/auth/register.blade.php ENDPATH**/ ?>