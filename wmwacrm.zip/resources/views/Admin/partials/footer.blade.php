<footer id="main-footer">
    <div id="footer-bottom">
        <div class="container clearfix" >

            <span class="info" style="font-size: 13px">
                ©2021 West Mercia Women’s Aid. West Mercia Women’s Aid is a company limited by guarantee registered
                in England No: 3837084
                <br>
                West Mercia Women’s Aid is a registered charity in England No. 1078496. Registered Office: Berrows
                Business Centre, Bath Street, Hereford, Herefordshire HR1 2HE
            </span>

            <span class="links" style="font-size: 13px"><a href="/privacy-policy/">Privacy Policy</a> | <a
                    href="/disclaimer/">Disclaimer</a> | <a href="/login">Login</a> | <a href="/site-map/">Site
                    Map</a> | <a href="http://www.fromthesticks.co.uk" target="_blank">Website by From the
                    Sticks</a></span>

        </div> <!-- .container -->
    </div>
</footer>