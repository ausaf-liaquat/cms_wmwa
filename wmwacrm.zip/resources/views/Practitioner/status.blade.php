@extends('layouts.master')
@section('title') Status @endsection
@section('content')
    <Span>
        Your account Status is Pending
    </Span>
@endsection
